package com.ecom.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ecom.Entity.Supplier;

@Repository("supplierDAO")
public class SupplierImplementation implements SupplierDAO
{
	@Autowired
	SessionFactory sessionfactory;
	
	@Transactional
	@Override
	public boolean addSupplier(Supplier supplier) {
		try {
			sessionfactory.getCurrentSession().save(supplier);
			return true;
		}
		catch(Exception e) {
			return false;
		}
		
	}

	@Override
	public boolean updateSupplier(Supplier supplier) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteSupplier(Supplier supplier) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Supplier> getSuppliers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Supplier getSupplier(int supplierID) {
		// TODO Auto-generated method stub
		return null;
	}

}
