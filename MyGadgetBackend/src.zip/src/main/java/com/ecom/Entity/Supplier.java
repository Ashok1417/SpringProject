package com.ecom.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity //Mapping Process
@Table  //Mapping Process
public class Supplier
{
	@Id
	int SupplierID;
	String SupplierName;
	
	public int getSupplierID() {
		return SupplierID;
	}
	
	public void setSupplierID(int supplierID) {
		SupplierID = supplierID;
	}
	
	public String getSupplierName() {
		return SupplierName;
	}
	
	public void setSupplierName(String supplierName) {
		SupplierName = supplierName;
	}
	
}
