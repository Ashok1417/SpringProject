package com.ecom.SampTest;

import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ecom.Entity.Supplier;
import com.ecom.dao.SupplierDAO;

public class SupplierDAOTest 
{
	static SupplierDAO supplierdao;
	
	@BeforeClass
	public static void initialize() 
	{
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.ecom");
		context.refresh();
		
		supplierdao=(SupplierDAO)context.getBean("supplierDAO");
	}
	
	@Test
	public void addSupplierTest()
	{
		Supplier supplier = new Supplier();
		supplier.setSupplierID(1001);
		supplier.setSupplierName("Ashok");
		
		assertTrue("Problem Occured While Adding Supplier :", supplierdao.addSupplier(supplier));
	}
}
